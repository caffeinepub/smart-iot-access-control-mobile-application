import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Send, Mic, Settings, Plus, MessageSquare, Zap, LogOut, Volume2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function Dashboard() {
  const { user, loading, logout } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // tRPC queries and mutations
  const conversationsQuery = trpc.conversations.list.useQuery();
  const createConversationMutation = trpc.conversations.create.useMutation();
  const getConversationQuery = trpc.conversations.get.useQuery(
    { conversationId: currentConversationId || 0 },
    { enabled: !!currentConversationId }
  );
  const sendMessageMutation = trpc.chat.send.useMutation();

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Load conversation on selection
  useEffect(() => {
    if (getConversationQuery.data) {
      setMessages(getConversationQuery.data.messages);
    }
  }, [getConversationQuery.data]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="typing-indicator">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    );
  }

  const handleNewChat = async () => {
    try {
      await createConversationMutation.mutateAsync({
        title: `Chat - ${new Date().toLocaleString()}`,
      });
      await conversationsQuery.refetch();
      setMessages([]);
      setCurrentConversationId(null);
      toast.success("New conversation created!");
    } catch (error) {
      toast.error("Failed to create conversation");
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || !currentConversationId) {
      toast.error("Please start a conversation first");
      return;
    }

    const userMessage = input;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setIsSending(true);

    try {
      const response = await sendMessageMutation.mutateAsync({
        conversationId: currentConversationId,
        message: userMessage,
      });

      if (response.success) {
        setMessages((prev) => [...prev, { role: "assistant", content: response.message }]);
      }
    } catch (error) {
      toast.error("Failed to send message");
      setMessages((prev) => prev.slice(0, -1));
    } finally {
      setIsSending(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/wav" });
        // TODO: Send audio to transcription API
        toast.info("Voice recording captured (transcription coming soon)");
      };

      mediaRecorder.start();
      setIsRecording(true);
      toast.info("Recording started...");
    } catch (error) {
      toast.error("Microphone access denied");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
      setIsRecording(false);
      toast.info("Recording stopped");
    }
  };

  const conversations = conversationsQuery.data || [];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Main Layout */}
      <div className="flex h-screen">
        {/* Sidebar */}
        <div className="w-64 bg-card border-r border-border neon-border-pink p-4 flex flex-col">
          <div className="mb-6">
            <h1 className="text-2xl font-bold neon-text mb-2">JARVIS</h1>
            <p className="text-xs text-muted-foreground">Your AI Companion</p>
          </div>

          {/* New Chat Button */}
          <Button className="w-full mb-6 btn-neon" onClick={handleNewChat}>
            <Plus className="w-4 h-4 mr-2" />
            New Chat
          </Button>

          {/* Chat History */}
          <div className="flex-1 overflow-y-auto">
            <div className="text-xs text-muted-foreground mb-3 font-bold">RECENT</div>
            <div className="space-y-2">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => setCurrentConversationId(conv.id)}
                  className={`p-2 rounded text-sm cursor-pointer transition-colors neon-border ${
                    currentConversationId === conv.id
                      ? "bg-accent text-accent-foreground neon-border-pink"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  {conv.title}
                </div>
              ))}
            </div>
          </div>

          {/* User Profile */}
          <div className="border-t border-border pt-4 mt-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-semibold">{user?.name || "User"}</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm">
                  <Settings className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => logout()}>
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="border-b border-border p-4 flex items-center justify-between neon-border-pink">
            <div>
              <h2 className="text-lg font-bold neon-text-cyan">Chat with Jarvis</h2>
              <p className="text-xs text-muted-foreground">Your AI friend is ready to help</p>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-neon-cyan" />
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 scan-effect">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <MessageSquare className="w-16 h-16 text-muted-foreground mb-4 opacity-50" />
                <h3 className="text-xl font-bold neon-text mb-2">Welcome to Jarvis</h3>
                <p className="text-muted-foreground max-w-md">
                  Start a conversation with your AI companion. Ask me anything, and I'll help you
                  with tasks, productivity, or just a friendly chat.
                </p>
              </div>
            ) : (
              <>
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} message-enter`}
                  >
                    <div
                      className={`max-w-md px-4 py-3 rounded-lg ${
                        msg.role === "user"
                          ? "bg-accent text-accent-foreground neon-border-pink"
                          : "bg-card text-foreground neon-border"
                      }`}
                    >
                      {msg.role === "assistant" ? (
                        <Streamdown>{msg.content}</Streamdown>
                      ) : (
                        <p className="text-sm">{msg.content}</p>
                      )}
                    </div>
                  </div>
                ))}
                {isSending && (
                  <div className="flex justify-start">
                    <div className="bg-card text-foreground neon-border px-4 py-3 rounded-lg">
                      <div className="typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {/* Input Area */}
          <div className="border-t border-border p-4 neon-border-pink">
            <div className="flex gap-2 mb-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && !isSending && handleSendMessage()}
                placeholder="Type your message... or use voice"
                className="flex-1 bg-card border-border neon-border"
                disabled={isSending}
              />
              <Button
                size="icon"
                variant="outline"
                onClick={isRecording ? stopRecording : startRecording}
                className={isRecording ? "btn-neon" : ""}
              >
                <Mic className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                className="btn-neon"
                onClick={handleSendMessage}
                disabled={isSending || !input.trim()}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              💡 Tip: Use voice input for hands-free interaction or press Enter to send
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
