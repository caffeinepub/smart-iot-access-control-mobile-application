import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { Zap, Brain, Mic, Sparkles, TrendingUp, Shield } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="typing-indicator">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    navigate("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Animated Background Grid */}
      <div className="fixed inset-0 opacity-10 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-neon-cyan via-transparent to-neon-pink"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-10 border-b border-border neon-border-pink backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-8 h-8 text-neon-pink" />
            <h1 className="text-2xl font-bold neon-text">JARVIS</h1>
          </div>
          <div className="text-xs text-muted-foreground">
            Your Futuristic AI Companion
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div>
              <h2 className="text-5xl md:text-6xl font-bold mb-4">
                <span className="neon-text">Meet Jarvis</span>
                <br />
                <span className="neon-text-cyan">Your AI Friend</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Experience the future of productivity. Jarvis combines advanced AI, voice interaction,
                and intelligent task management to become your perfect digital companion.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Brain, label: "AI Powered", desc: "Advanced conversations" },
                { icon: Mic, label: "Voice Control", desc: "Hands-free interaction" },
                { icon: TrendingUp, label: "Productivity", desc: "Task & time tracking" },
                { icon: Sparkles, label: "Smart", desc: "Learns your patterns" },
              ].map((feature, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-lg neon-border bg-card/50 hover:bg-card transition-colors"
                >
                  <feature.icon className="w-6 h-6 text-neon-cyan mb-2" />
                  <p className="font-semibold text-sm">{feature.label}</p>
                  <p className="text-xs text-muted-foreground">{feature.desc}</p>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex gap-4 pt-4">
              <Button
                size="lg"
                className="btn-neon"
                onClick={() => window.location.href = getLoginUrl()}
              >
                <Zap className="w-4 h-4 mr-2" />
                Get Started Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="neon-border border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10"
              >
                Learn More
              </Button>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative h-96 hidden md:flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-neon-pink/20 to-neon-cyan/20 rounded-2xl blur-3xl"></div>
            <div className="relative z-10 w-full h-full rounded-2xl neon-border-pink border-2 flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-card to-background"></div>
              <div className="relative z-10 text-center space-y-4">
                <div className="text-6xl">🤖</div>
                <p className="text-sm text-muted-foreground">Jarvis AI Interface</p>
                <div className="typing-indicator justify-center">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-20 border-t border-border">
        <h3 className="text-3xl font-bold neon-text mb-12 text-center">
          Packed with Superpowers
        </h3>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              title: "Intelligent Chat",
              desc: "Have natural conversations with advanced AI that understands context and learns from you.",
              icon: Brain,
            },
            {
              title: "Voice Interaction",
              desc: "Speak naturally with voice input and listen to AI responses with natural speech synthesis.",
              icon: Mic,
            },
            {
              title: "Productivity Suite",
              desc: "Kanban boards, time tracking, habit streaks, and wellness features all in one place.",
              icon: TrendingUp,
            },
            {
              title: "Real-time Search",
              desc: "Jarvis searches the web to provide you with the latest information beyond training data.",
              icon: Zap,
            },
            {
              title: "Image Generation",
              desc: "Create stunning images with AI-powered generation based on your descriptions.",
              icon: Sparkles,
            },
            {
              title: "Privacy First",
              desc: "Your conversations and data are encrypted and secure. You control what Jarvis knows.",
              icon: Shield,
            },
          ].map((feature, idx) => (
            <div
              key={idx}
              className="p-6 rounded-lg neon-border bg-card/50 hover:bg-card transition-all hover:shadow-lg hover:shadow-neon-pink/20"
            >
              <feature.icon className="w-8 h-8 text-neon-cyan mb-4" />
              <h4 className="text-lg font-bold mb-2">{feature.title}</h4>
              <p className="text-sm text-muted-foreground">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative z-10 max-w-4xl mx-auto px-4 py-20">
        <div className="rounded-2xl neon-border-pink border-2 p-12 text-center bg-gradient-to-br from-card/50 to-background/50">
          <h3 className="text-3xl font-bold neon-text mb-4">
            Ready to Meet Jarvis?
          </h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of users who are already experiencing the future of AI-powered productivity.
            Start your journey with Jarvis today.
          </p>
          <Button
            size="lg"
            className="btn-neon"
            onClick={() => window.location.href = getLoginUrl()}
          >
            <Zap className="w-4 h-4 mr-2" />
            Launch Jarvis
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border mt-20 py-8 text-center text-sm text-muted-foreground">
        <p>© 2026 Jarvis AI. Crafted with ❤️ and neon lights.</p>
      </footer>
    </div>
  );
}
