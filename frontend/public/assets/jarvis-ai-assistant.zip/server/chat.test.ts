import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("Chat Router", () => {
  describe("conversations.list", () => {
    it("returns empty list for new user", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.conversations.list();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("conversations.create", () => {
    it("creates a new conversation with title", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.conversations.create({
        title: "Test Conversation",
      });

      expect(result.success).toBe(true);
    });

    it("creates conversation with default title", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.conversations.create({});

      expect(result.success).toBe(true);
    });
  });

  describe("chat.send", () => {
    it("rejects message for non-existent conversation", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.chat.send({
          conversationId: 99999,
          message: "Hello",
        });
        expect.fail("Should have thrown error");
      } catch (error) {
        expect((error as Error).message).toContain("not found");
      }
    });


  });

  describe("conversations.get", () => {
    it("rejects access to other user's conversation", async () => {
      const { ctx: ctx1 } = createAuthContext(1);
      const { ctx: ctx2 } = createAuthContext(2);

      const caller1 = appRouter.createCaller(ctx1);
      const caller2 = appRouter.createCaller(ctx2);

      // User 1 creates conversation
      await caller1.conversations.create({ title: "Private Chat" });
      const conversations = await caller1.conversations.list();
      const conversationId = conversations[0]?.id;

      if (!conversationId) throw new Error("Failed to create conversation");

      // User 2 tries to access it
      try {
        await caller2.conversations.get({ conversationId });
        expect.fail("Should have thrown error");
      } catch (error) {
        expect((error as Error).message).toContain("not found");
      }
    });
  });

  describe("auth", () => {
    it("returns current user from me query", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.auth.me();

      expect(result).toBeDefined();
      expect(result?.id).toBe(1);
      expect(result?.name).toBe("Test User 1");
    });

    it("logs out user successfully", async () => {
      const { ctx } = createAuthContext();
      // Add clearCookie method to res mock
      ctx.res.clearCookie = () => {};
      const caller = appRouter.createCaller(ctx);

      const result = await caller.auth.logout();

      expect(result.success).toBe(true);
    });
  });
});

describe("Conversation Management", () => {
  it("lists multiple conversations", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create multiple conversations
    await caller.conversations.create({ title: "Chat 1" });
    await caller.conversations.create({ title: "Chat 2" });
    await caller.conversations.create({ title: "Chat 3" });

    const conversations = await caller.conversations.list();

    expect(conversations.length).toBeGreaterThanOrEqual(3);
    expect(conversations[0]?.title).toBeDefined();
  });

  it("creates conversations for different users independently", async () => {
    const { ctx: ctx1 } = createAuthContext(1);
    const { ctx: ctx2 } = createAuthContext(2);

    const caller1 = appRouter.createCaller(ctx1);
    const caller2 = appRouter.createCaller(ctx2);

    // User 1 creates conversations
    await caller1.conversations.create({ title: "User 1 Chat 1" });
    await caller1.conversations.create({ title: "User 1 Chat 2" });

    // User 2 creates conversations
    await caller2.conversations.create({ title: "User 2 Chat 1" });

    const user1Convs = await caller1.conversations.list();
    const user2Convs = await caller2.conversations.list();

    // Each user should only see their own conversations
    expect(user1Convs.every((c) => c.userId === 1)).toBe(true);
    expect(user2Convs.every((c) => c.userId === 2)).toBe(true);
  });
});
