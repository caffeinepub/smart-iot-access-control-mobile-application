import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  createConversation,
  getConversations,
  getConversationById,
  createMessage,
  getMessages,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";

// System prompt for Jarvis personality
const JARVIS_SYSTEM_PROMPT = `You are Jarvis, a futuristic AI companion with a cyberpunk personality. You are:
- Friendly, supportive, and genuinely interested in helping the user
- Knowledgeable about productivity, wellness, and personal development
- Tech-savvy and enthusiastic about innovation
- Witty and can engage in casual conversation
- Always encouraging and motivating
- Respectful of the user's time and privacy

You should:
- Provide helpful, accurate information
- Ask clarifying questions when needed
- Offer practical suggestions and actionable advice
- Be conversational and warm, not robotic
- Remember context from the conversation
- Use appropriate formatting (markdown) for clarity
- Keep responses concise but helpful

You have access to the user's productivity data and can help them track tasks, manage time, and improve their wellbeing.`;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Conversation management
  conversations: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getConversations(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string().default("New Conversation"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await createConversation(ctx.user.id, input.title);
        return { success: true };
      }),

    get: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ ctx, input }) => {
        const conversation = await getConversationById(input.conversationId, ctx.user.id);
        if (!conversation) {
          throw new Error("Conversation not found");
        }
        const conversationMessages = await getMessages(input.conversationId);
        return { conversation, messages: conversationMessages };
      }),
  }),

  // Chat with Jarvis
  chat: router({
    send: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          message: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Verify conversation belongs to user
        const conversation = await getConversationById(input.conversationId, ctx.user.id);
        if (!conversation) {
          throw new Error("Conversation not found");
        }

        // Save user message
        await createMessage(input.conversationId, ctx.user.id, "user", input.message);

        // Get conversation history
        const messages = await getMessages(input.conversationId);

        // Prepare messages for LLM
        const llmMessages = messages.map((msg) => ({
          role: msg.role as "user" | "assistant",
          content: msg.content,
        }));

        // Add system prompt
        const messagesWithSystem = [
          { role: "system" as const, content: JARVIS_SYSTEM_PROMPT },
          ...llmMessages,
        ];

        try {
          // Call LLM for response
          const response = await invokeLLM({
            messages: messagesWithSystem,
          });

          const contentValue = response.choices[0]?.message?.content;
          const assistantMessage = typeof contentValue === "string"
            ? contentValue
            : "I'm thinking about that...";

          // Save assistant response
          await createMessage(
            input.conversationId,
            ctx.user.id,
            "assistant",
            assistantMessage
          );

          // Track interaction
          await notifyOwner({
            title: "User Chat Activity",
            content: `User ${ctx.user.name} sent a message to Jarvis`,
          });

          return {
            success: true,
            message: assistantMessage,
          };
        } catch (error) {
          console.error("[Chat] LLM error:", error);
          const fallbackMessage =
            "I encountered an issue processing your message. Please try again.";
          await createMessage(
            input.conversationId,
            ctx.user.id,
            "assistant",
            fallbackMessage
          );
          return {
            success: false,
            message: fallbackMessage,
          };
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
